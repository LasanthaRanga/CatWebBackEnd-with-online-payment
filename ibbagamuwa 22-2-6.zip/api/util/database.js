const mysql = require('mysql2');

const pool = mysql.createPool({
    host: "124.43.5.82",
    user:"root",
    password:"IBB@#$321$%",
    database:"online_test",
    port: 3306
    // host: '124.43.23.214',
    // host: '124.43.11.162',

    // user: 'root',
    // password: '3ta@kela#una@',
    // database: 'kalpitiyaps',

    // password: 'CHI@#321#',
    // database: 'ultimate2'

    // password: 'KULIUC@#321#',
    // database: 'ibbagamuwaps'

});

module.exports = pool.promise();